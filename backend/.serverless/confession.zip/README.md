# anonymous_twitter

Quickstart

```
cd confession
npm install
```

Deployment

````
serverless deploy
```

Test
```
serverless invoke --function create
```
