const { Firestore } = require("@google-cloud/firestore");

const firestore = new Firestore();

exports.create = (request, response) => {
  const tag = request.body.tag;
  const content = request.body.content;
  const postsCol = firestore.collection("tags").doc(tag).collection("posts");
  postsCol
    .add({
      content: content,
      created_at: new Date(),
      like_count: 0,
    })
    .catch((error) => {
      response.status(500).send(error);
    })
    .then((data) => {
      response.status(200).send("OK");
    });
};

exports.fetch = (request, resposne) => {
  const tag = request.body.tag;
  const cursor = request.body.cursor;
  const limit = request.body.limit;
  const tagDoc = firestore.collection("tags").doc(tag);
  const cursorDoc = tagDoc.collection("posts").doc(cursor);
  const resultsQuery = tagDoc
    .collection("posts")
    .orderBy("created_at")
    .startAfter(cursorDoc)
    .limit(limit);
  let paginate = resultsQuery
    .get()
    .then((snapshot) => {
      let last = snapshot.docs[snapshot.docs.length - 1];

      resposne.json({
        result: snapshot.docs.map((doc) => {
          result = doc.data();
          result.id = doc.id;
          return result;
        }),
        cursor: last.id,
      });
    })
    .catch((error) => {
      response.status(500).send(error);
    });
};

exports.test = (request, response) => {
  response.status(200).send("OK");
};
